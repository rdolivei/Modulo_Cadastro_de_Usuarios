USE [BancoUsuarios]
GO

/****** Object:  Table [dbo].[Usuarios]    Script Date: 19/09/2020 20:47:30 ******/
DROP TABLE [dbo].[Usuarios]
GO

/****** Object:  Table [dbo].[Usuarios]    Script Date: 19/09/2020 20:47:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Usuarios](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[nome] [nvarchar](50) NULL,
	[login] [nvarchar](50) NOT NULL,
	[senha] [nvarchar](70) NOT NULL,
	[nivel] [int] NULL
) ON [PRIMARY]

GO


