﻿namespace Supervisorio
{
    internal class SqlCeDataReader
    {
    }
}