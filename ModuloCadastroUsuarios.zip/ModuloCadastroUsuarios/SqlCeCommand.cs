﻿using System;
using System.Data.SqlClient;

namespace Supervisorio
{
    internal class SqlCeCommand
    {
        private string sql;
        private SqlConnection conexBD;

        public SqlCeCommand(string sql, SqlConnection conexBD)
        {
            this.sql = sql;
            this.conexBD = conexBD;
        }

        internal SqlCeDataReader ExecuteReader()
        {
            throw new NotImplementedException();
        }
    }
}