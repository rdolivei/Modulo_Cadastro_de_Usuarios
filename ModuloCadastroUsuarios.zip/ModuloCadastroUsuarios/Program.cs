﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.CompilerServices;
[assembly: SuppressIldasmAttribute()]

namespace Supervisorio
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            string nomeProcesso = Process.GetCurrentProcess().ProcessName; // Aqui pega o nome do Processo do Supervisorio
            Process[] processoRodando = Process.GetProcessesByName(nomeProcesso);// Procura pelo processo rodando no PC
            if (processoRodando != null && processoRodando.Length > 1) //Aqui se ja tem um rodando avisa
            {
                MessageBox.Show("Supervisório Usuários já está sendo executado em outra janela!", "*** AVISO ***", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form_Principal());
            }

        }
    }
}
