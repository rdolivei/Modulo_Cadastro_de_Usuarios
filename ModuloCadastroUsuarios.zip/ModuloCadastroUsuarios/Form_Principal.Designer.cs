﻿namespace Supervisorio
{
    partial class Form_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Principal));
            this.lblMostraLogado = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblHora = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.lblInfoLeitura = new System.Windows.Forms.Label();
            this.lblInfoErro = new System.Windows.Forms.Label();
            this.lblInfoBanco = new System.Windows.Forms.Label();
            this.tabPage6_Info = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.tabPage5_Excluir = new System.Windows.Forms.TabPage();
            this.BtnExcluir = new System.Windows.Forms.Button();
            this.tabPage4_Atualizar = new System.Windows.Forms.TabPage();
            this.BtnAtualizar = new System.Windows.Forms.Button();
            this.tabPage3_Visualizar = new System.Windows.Forms.TabPage();
            this.txbNivelVisualizar = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txbNomeVisualizar = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txbLoginVisualizar = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridView_Visualizar = new System.Windows.Forms.DataGridView();
            this.BtnVisualizar = new System.Windows.Forms.Button();
            this.tabPage2_Cadastrar = new System.Windows.Forms.TabPage();
            this.txbNivelCadastro = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txbNomeCadastro = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txbSenhaCadastro = new System.Windows.Forms.TextBox();
            this.txbLoginCadastro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.BtnCadastrar = new System.Windows.Forms.Button();
            this.tabPage1_Login = new System.Windows.Forms.TabPage();
            this.btnDeslogar = new System.Windows.Forms.Button();
            this.btnLogar = new System.Windows.Forms.Button();
            this.tbxSenha = new System.Windows.Forms.TextBox();
            this.tbxUsuario = new System.Windows.Forms.TextBox();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Abas = new System.Windows.Forms.TabControl();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.imgUsuarioLogado = new System.Windows.Forms.PictureBox();
            this.imgUsuario = new System.Windows.Forms.PictureBox();
            this.tx_TamanhoBanco = new System.Windows.Forms.Label();
            this.tabPage6_Info.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage5_Excluir.SuspendLayout();
            this.tabPage4_Atualizar.SuspendLayout();
            this.tabPage3_Visualizar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Visualizar)).BeginInit();
            this.tabPage2_Cadastrar.SuspendLayout();
            this.tabPage1_Login.SuspendLayout();
            this.Abas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.imgUsuarioLogado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgUsuario)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMostraLogado
            // 
            this.lblMostraLogado.AutoSize = true;
            this.lblMostraLogado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lblMostraLogado.ForeColor = System.Drawing.Color.White;
            this.lblMostraLogado.Location = new System.Drawing.Point(65, 20);
            this.lblMostraLogado.Name = "lblMostraLogado";
            this.lblMostraLogado.Size = new System.Drawing.Size(126, 20);
            this.lblMostraLogado.TabIndex = 0;
            this.lblMostraLogado.Text = "Usuário Logado:";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lblHora
            // 
            this.lblHora.AutoSize = true;
            this.lblHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHora.Location = new System.Drawing.Point(571, 4);
            this.lblHora.Name = "lblHora";
            this.lblHora.Size = new System.Drawing.Size(38, 31);
            this.lblHora.TabIndex = 1;
            this.lblHora.Text = "...";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(380, 4);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(38, 31);
            this.lblData.TabIndex = 2;
            this.lblData.Text = "...";
            // 
            // lblInfoLeitura
            // 
            this.lblInfoLeitura.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblInfoLeitura.AutoSize = true;
            this.lblInfoLeitura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoLeitura.ForeColor = System.Drawing.Color.Blue;
            this.lblInfoLeitura.Location = new System.Drawing.Point(19, 632);
            this.lblInfoLeitura.Name = "lblInfoLeitura";
            this.lblInfoLeitura.Size = new System.Drawing.Size(17, 16);
            this.lblInfoLeitura.TabIndex = 10;
            this.lblInfoLeitura.Text = "...";
            // 
            // lblInfoErro
            // 
            this.lblInfoErro.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblInfoErro.AutoSize = true;
            this.lblInfoErro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoErro.ForeColor = System.Drawing.Color.Red;
            this.lblInfoErro.Location = new System.Drawing.Point(19, 648);
            this.lblInfoErro.Name = "lblInfoErro";
            this.lblInfoErro.Size = new System.Drawing.Size(17, 16);
            this.lblInfoErro.TabIndex = 412;
            this.lblInfoErro.Text = "...";
            // 
            // lblInfoBanco
            // 
            this.lblInfoBanco.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblInfoBanco.AutoSize = true;
            this.lblInfoBanco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoBanco.ForeColor = System.Drawing.Color.Red;
            this.lblInfoBanco.Location = new System.Drawing.Point(19, 683);
            this.lblInfoBanco.Name = "lblInfoBanco";
            this.lblInfoBanco.Size = new System.Drawing.Size(17, 16);
            this.lblInfoBanco.TabIndex = 413;
            this.lblInfoBanco.Text = "...";
            // 
            // tabPage6_Info
            // 
            this.tabPage6_Info.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage6_Info.Controls.Add(this.tx_TamanhoBanco);
            this.tabPage6_Info.Controls.Add(this.pictureBox1);
            this.tabPage6_Info.Controls.Add(this.label8);
            this.tabPage6_Info.Controls.Add(this.label7);
            this.tabPage6_Info.Controls.Add(this.label44);
            this.tabPage6_Info.Controls.Add(this.label16);
            this.tabPage6_Info.ImageIndex = 5;
            this.tabPage6_Info.Location = new System.Drawing.Point(4, 33);
            this.tabPage6_Info.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage6_Info.Name = "tabPage6_Info";
            this.tabPage6_Info.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage6_Info.Size = new System.Drawing.Size(1477, 533);
            this.tabPage6_Info.TabIndex = 14;
            this.tabPage6_Info.Text = "Informações";
            this.tabPage6_Info.Click += new System.EventHandler(this.TabPage10_Sobre_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SupervisorioUsuarios.Properties.Resources.R;
            this.pictureBox1.Location = new System.Drawing.Point(23, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(429, 444);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 420;
            this.pictureBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(520, 437);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(90, 32);
            this.label8.TabIndex = 419;
            this.label8.Text = "#2020";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(520, 221);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(227, 32);
            this.label7.TabIndex = 418;
            this.label7.Text = "Ricardo Oliveira";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(519, 25);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(413, 32);
            this.label44.TabIndex = 417;
            this.label44.Text = "Projeto Supervisório Usuários";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(1418, 515);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 14);
            this.label16.TabIndex = 370;
            this.label16.Text = "v 0_9_21";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabPage5_Excluir
            // 
            this.tabPage5_Excluir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage5_Excluir.Controls.Add(this.BtnExcluir);
            this.tabPage5_Excluir.ImageIndex = 2;
            this.tabPage5_Excluir.Location = new System.Drawing.Point(4, 33);
            this.tabPage5_Excluir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage5_Excluir.Name = "tabPage5_Excluir";
            this.tabPage5_Excluir.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage5_Excluir.Size = new System.Drawing.Size(1477, 533);
            this.tabPage5_Excluir.TabIndex = 4;
            this.tabPage5_Excluir.Text = "Excluir";
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnExcluir.ForeColor = System.Drawing.Color.Black;
            this.BtnExcluir.Image = global::SupervisorioUsuarios.Properties.Resources.Deletar;
            this.BtnExcluir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnExcluir.Location = new System.Drawing.Point(494, 147);
            this.BtnExcluir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Size = new System.Drawing.Size(200, 60);
            this.BtnExcluir.TabIndex = 461;
            this.BtnExcluir.Text = "   Excluir";
            this.BtnExcluir.UseVisualStyleBackColor = true;
            // 
            // tabPage4_Atualizar
            // 
            this.tabPage4_Atualizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage4_Atualizar.Controls.Add(this.BtnAtualizar);
            this.tabPage4_Atualizar.ImageIndex = 9;
            this.tabPage4_Atualizar.Location = new System.Drawing.Point(4, 33);
            this.tabPage4_Atualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4_Atualizar.Name = "tabPage4_Atualizar";
            this.tabPage4_Atualizar.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage4_Atualizar.Size = new System.Drawing.Size(1477, 533);
            this.tabPage4_Atualizar.TabIndex = 3;
            this.tabPage4_Atualizar.Text = "Atualizar";
            // 
            // BtnAtualizar
            // 
            this.BtnAtualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAtualizar.ForeColor = System.Drawing.Color.Black;
            this.BtnAtualizar.Image = global::SupervisorioUsuarios.Properties.Resources.Editar;
            this.BtnAtualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnAtualizar.Location = new System.Drawing.Point(484, 158);
            this.BtnAtualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnAtualizar.Name = "BtnAtualizar";
            this.BtnAtualizar.Size = new System.Drawing.Size(200, 60);
            this.BtnAtualizar.TabIndex = 460;
            this.BtnAtualizar.Text = "    Atualizar";
            this.BtnAtualizar.UseVisualStyleBackColor = true;
            // 
            // tabPage3_Visualizar
            // 
            this.tabPage3_Visualizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage3_Visualizar.Controls.Add(this.txbNivelVisualizar);
            this.tabPage3_Visualizar.Controls.Add(this.label9);
            this.tabPage3_Visualizar.Controls.Add(this.txbNomeVisualizar);
            this.tabPage3_Visualizar.Controls.Add(this.label10);
            this.tabPage3_Visualizar.Controls.Add(this.txbLoginVisualizar);
            this.tabPage3_Visualizar.Controls.Add(this.label11);
            this.tabPage3_Visualizar.Controls.Add(this.dataGridView_Visualizar);
            this.tabPage3_Visualizar.Controls.Add(this.BtnVisualizar);
            this.tabPage3_Visualizar.ImageIndex = 4;
            this.tabPage3_Visualizar.Location = new System.Drawing.Point(4, 33);
            this.tabPage3_Visualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3_Visualizar.Name = "tabPage3_Visualizar";
            this.tabPage3_Visualizar.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage3_Visualizar.Size = new System.Drawing.Size(1477, 533);
            this.tabPage3_Visualizar.TabIndex = 2;
            this.tabPage3_Visualizar.Text = "Visualizar";
            // 
            // txbNivelVisualizar
            // 
            this.txbNivelVisualizar.AcceptsReturn = true;
            this.txbNivelVisualizar.AccessibleDescription = "";
            this.txbNivelVisualizar.AccessibleName = "";
            this.txbNivelVisualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNivelVisualizar.Location = new System.Drawing.Point(350, 127);
            this.txbNivelVisualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbNivelVisualizar.MaxLength = 20;
            this.txbNivelVisualizar.Name = "txbNivelVisualizar";
            this.txbNivelVisualizar.Size = new System.Drawing.Size(200, 38);
            this.txbNivelVisualizar.TabIndex = 466;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(246, 131);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 31);
            this.label9.TabIndex = 464;
            this.label9.Text = "Nível:";
            // 
            // txbNomeVisualizar
            // 
            this.txbNomeVisualizar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txbNomeVisualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNomeVisualizar.Location = new System.Drawing.Point(350, 43);
            this.txbNomeVisualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbNomeVisualizar.MaxLength = 20;
            this.txbNomeVisualizar.Name = "txbNomeVisualizar";
            this.txbNomeVisualizar.Size = new System.Drawing.Size(200, 38);
            this.txbNomeVisualizar.TabIndex = 463;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(235, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(94, 31);
            this.label10.TabIndex = 462;
            this.label10.Text = "Nome:";
            // 
            // txbLoginVisualizar
            // 
            this.txbLoginVisualizar.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txbLoginVisualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbLoginVisualizar.Location = new System.Drawing.Point(350, 85);
            this.txbLoginVisualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbLoginVisualizar.MaxLength = 20;
            this.txbLoginVisualizar.Name = "txbLoginVisualizar";
            this.txbLoginVisualizar.Size = new System.Drawing.Size(200, 38);
            this.txbLoginVisualizar.TabIndex = 465;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(213, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(116, 31);
            this.label11.TabIndex = 461;
            this.label11.Text = "Usuário:";
            // 
            // dataGridView_Visualizar
            // 
            this.dataGridView_Visualizar.AllowUserToAddRows = false;
            this.dataGridView_Visualizar.AllowUserToDeleteRows = false;
            this.dataGridView_Visualizar.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_Visualizar.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView_Visualizar.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.dataGridView_Visualizar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView_Visualizar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Visualizar.GridColor = System.Drawing.Color.Gray;
            this.dataGridView_Visualizar.Location = new System.Drawing.Point(90, 265);
            this.dataGridView_Visualizar.Name = "dataGridView_Visualizar";
            this.dataGridView_Visualizar.ReadOnly = true;
            this.dataGridView_Visualizar.Size = new System.Drawing.Size(696, 228);
            this.dataGridView_Visualizar.TabIndex = 460;
            // 
            // BtnVisualizar
            // 
            this.BtnVisualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVisualizar.ForeColor = System.Drawing.Color.Black;
            this.BtnVisualizar.Image = global::SupervisorioUsuarios.Properties.Resources.Buscar;
            this.BtnVisualizar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnVisualizar.Location = new System.Drawing.Point(350, 183);
            this.BtnVisualizar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnVisualizar.Name = "BtnVisualizar";
            this.BtnVisualizar.Size = new System.Drawing.Size(200, 60);
            this.BtnVisualizar.TabIndex = 459;
            this.BtnVisualizar.Text = "     Visualizar";
            this.BtnVisualizar.UseVisualStyleBackColor = true;
            this.BtnVisualizar.Click += new System.EventHandler(this.BtnVisualizar_Click);
            // 
            // tabPage2_Cadastrar
            // 
            this.tabPage2_Cadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage2_Cadastrar.Controls.Add(this.txbNivelCadastro);
            this.tabPage2_Cadastrar.Controls.Add(this.label6);
            this.tabPage2_Cadastrar.Controls.Add(this.txbNomeCadastro);
            this.tabPage2_Cadastrar.Controls.Add(this.label5);
            this.tabPage2_Cadastrar.Controls.Add(this.txbSenhaCadastro);
            this.tabPage2_Cadastrar.Controls.Add(this.txbLoginCadastro);
            this.tabPage2_Cadastrar.Controls.Add(this.label1);
            this.tabPage2_Cadastrar.Controls.Add(this.label3);
            this.tabPage2_Cadastrar.Controls.Add(this.label4);
            this.tabPage2_Cadastrar.Controls.Add(this.label32);
            this.tabPage2_Cadastrar.Controls.Add(this.BtnCadastrar);
            this.tabPage2_Cadastrar.ImageIndex = 6;
            this.tabPage2_Cadastrar.Location = new System.Drawing.Point(4, 33);
            this.tabPage2_Cadastrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2_Cadastrar.Name = "tabPage2_Cadastrar";
            this.tabPage2_Cadastrar.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage2_Cadastrar.Size = new System.Drawing.Size(1477, 533);
            this.tabPage2_Cadastrar.TabIndex = 1;
            this.tabPage2_Cadastrar.Text = "Cadastrar";
            // 
            // txbNivelCadastro
            // 
            this.txbNivelCadastro.AcceptsReturn = true;
            this.txbNivelCadastro.AccessibleDescription = "";
            this.txbNivelCadastro.AccessibleName = "";
            this.txbNivelCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNivelCadastro.Location = new System.Drawing.Point(643, 229);
            this.txbNivelCadastro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbNivelCadastro.MaxLength = 20;
            this.txbNivelCadastro.Name = "txbNivelCadastro";
            this.txbNivelCadastro.Size = new System.Drawing.Size(200, 38);
            this.txbNivelCadastro.TabIndex = 418;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(539, 233);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 31);
            this.label6.TabIndex = 416;
            this.label6.Text = "Nível:";
            // 
            // txbNomeCadastro
            // 
            this.txbNomeCadastro.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txbNomeCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbNomeCadastro.Location = new System.Drawing.Point(643, 102);
            this.txbNomeCadastro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbNomeCadastro.MaxLength = 20;
            this.txbNomeCadastro.Name = "txbNomeCadastro";
            this.txbNomeCadastro.Size = new System.Drawing.Size(200, 38);
            this.txbNomeCadastro.TabIndex = 415;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(528, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 31);
            this.label5.TabIndex = 414;
            this.label5.Text = "Nome:";
            // 
            // txbSenhaCadastro
            // 
            this.txbSenhaCadastro.AccessibleDescription = "";
            this.txbSenhaCadastro.AccessibleName = "";
            this.txbSenhaCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbSenhaCadastro.Location = new System.Drawing.Point(643, 186);
            this.txbSenhaCadastro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbSenhaCadastro.MaxLength = 20;
            this.txbSenhaCadastro.Name = "txbSenhaCadastro";
            this.txbSenhaCadastro.PasswordChar = '*';
            this.txbSenhaCadastro.Size = new System.Drawing.Size(200, 38);
            this.txbSenhaCadastro.TabIndex = 417;
            // 
            // txbLoginCadastro
            // 
            this.txbLoginCadastro.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.txbLoginCadastro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txbLoginCadastro.Location = new System.Drawing.Point(643, 144);
            this.txbLoginCadastro.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txbLoginCadastro.MaxLength = 20;
            this.txbLoginCadastro.Name = "txbLoginCadastro";
            this.txbLoginCadastro.Size = new System.Drawing.Size(200, 38);
            this.txbLoginCadastro.TabIndex = 416;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(522, 190);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 31);
            this.label1.TabIndex = 410;
            this.label1.Text = "Senha:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(506, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(116, 31);
            this.label3.TabIndex = 409;
            this.label3.Text = "Usuário:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(573, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(271, 31);
            this.label4.TabIndex = 408;
            this.label4.Text = "Novo Cadastramento";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Enabled = false;
            this.label32.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(1166, 529);
            this.label32.Name = "label32";
            this.label32.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label32.Size = new System.Drawing.Size(38, 16);
            this.label32.TabIndex = 407;
            this.label32.Text = "Life Bit";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label32.Visible = false;
            // 
            // BtnCadastrar
            // 
            this.BtnCadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnCadastrar.ForeColor = System.Drawing.Color.Black;
            this.BtnCadastrar.Image = global::SupervisorioUsuarios.Properties.Resources.Salvar;
            this.BtnCadastrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnCadastrar.Location = new System.Drawing.Point(643, 285);
            this.BtnCadastrar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnCadastrar.Name = "BtnCadastrar";
            this.BtnCadastrar.Size = new System.Drawing.Size(200, 60);
            this.BtnCadastrar.TabIndex = 419;
            this.BtnCadastrar.Text = "   Cadastrar";
            this.BtnCadastrar.UseVisualStyleBackColor = true;
            this.BtnCadastrar.Click += new System.EventHandler(this.BtnCadastrar_Click);
            // 
            // tabPage1_Login
            // 
            this.tabPage1_Login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(81)))), ((int)(((byte)(82)))), ((int)(((byte)(90)))));
            this.tabPage1_Login.Controls.Add(this.btnDeslogar);
            this.tabPage1_Login.Controls.Add(this.btnLogar);
            this.tabPage1_Login.Controls.Add(this.tbxSenha);
            this.tabPage1_Login.Controls.Add(this.tbxUsuario);
            this.tabPage1_Login.Controls.Add(this.lblSenha);
            this.tabPage1_Login.Controls.Add(this.lblUsuario);
            this.tabPage1_Login.Controls.Add(this.label2);
            this.tabPage1_Login.ImageIndex = 10;
            this.tabPage1_Login.Location = new System.Drawing.Point(4, 33);
            this.tabPage1_Login.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1_Login.Name = "tabPage1_Login";
            this.tabPage1_Login.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tabPage1_Login.Size = new System.Drawing.Size(1477, 533);
            this.tabPage1_Login.TabIndex = 0;
            this.tabPage1_Login.Text = "Login";
            // 
            // btnDeslogar
            // 
            this.btnDeslogar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeslogar.ForeColor = System.Drawing.Color.Black;
            this.btnDeslogar.Image = ((System.Drawing.Image)(resources.GetObject("btnDeslogar.Image")));
            this.btnDeslogar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDeslogar.Location = new System.Drawing.Point(642, 315);
            this.btnDeslogar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnDeslogar.Name = "btnDeslogar";
            this.btnDeslogar.Size = new System.Drawing.Size(200, 60);
            this.btnDeslogar.TabIndex = 7;
            this.btnDeslogar.Text = "Logoff";
            this.btnDeslogar.UseVisualStyleBackColor = true;
            this.btnDeslogar.Click += new System.EventHandler(this.BtnDeslogar_Click);
            // 
            // btnLogar
            // 
            this.btnLogar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogar.ForeColor = System.Drawing.Color.Black;
            this.btnLogar.Image = ((System.Drawing.Image)(resources.GetObject("btnLogar.Image")));
            this.btnLogar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogar.Location = new System.Drawing.Point(642, 247);
            this.btnLogar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnLogar.Name = "btnLogar";
            this.btnLogar.Size = new System.Drawing.Size(200, 60);
            this.btnLogar.TabIndex = 6;
            this.btnLogar.Text = "Login";
            this.btnLogar.UseVisualStyleBackColor = true;
            this.btnLogar.Click += new System.EventHandler(this.BtnLogar_Click);
            // 
            // tbxSenha
            // 
            this.tbxSenha.AccessibleDescription = "";
            this.tbxSenha.AccessibleName = "";
            this.tbxSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxSenha.Location = new System.Drawing.Point(642, 177);
            this.tbxSenha.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbxSenha.MaxLength = 20;
            this.tbxSenha.Name = "tbxSenha";
            this.tbxSenha.PasswordChar = '*';
            this.tbxSenha.Size = new System.Drawing.Size(200, 38);
            this.tbxSenha.TabIndex = 4;
            this.tbxSenha.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MeuEventoLogarEnter);
            // 
            // tbxUsuario
            // 
            this.tbxUsuario.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.tbxUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxUsuario.Location = new System.Drawing.Point(642, 135);
            this.tbxUsuario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbxUsuario.MaxLength = 20;
            this.tbxUsuario.Name = "tbxUsuario";
            this.tbxUsuario.Size = new System.Drawing.Size(200, 38);
            this.tbxUsuario.TabIndex = 3;
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSenha.Location = new System.Drawing.Point(521, 181);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(100, 31);
            this.lblSenha.TabIndex = 2;
            this.lblSenha.Text = "Senha:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUsuario.Location = new System.Drawing.Point(505, 139);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(116, 31);
            this.lblUsuario.TabIndex = 1;
            this.lblUsuario.Text = "Usuário:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(572, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(407, 31);
            this.label2.TabIndex = 0;
            this.label2.Text = "Sistema Supervisão de Usuários";
            // 
            // Abas
            // 
            this.Abas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Abas.Controls.Add(this.tabPage1_Login);
            this.Abas.Controls.Add(this.tabPage2_Cadastrar);
            this.Abas.Controls.Add(this.tabPage3_Visualizar);
            this.Abas.Controls.Add(this.tabPage4_Atualizar);
            this.Abas.Controls.Add(this.tabPage5_Excluir);
            this.Abas.Controls.Add(this.tabPage6_Info);
            this.Abas.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Abas.ImageList = this.imageList1;
            this.Abas.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Abas.Location = new System.Drawing.Point(-5, 57);
            this.Abas.Margin = new System.Windows.Forms.Padding(3, 5, 0, 5);
            this.Abas.Name = "Abas";
            this.Abas.SelectedIndex = 0;
            this.Abas.Size = new System.Drawing.Size(1485, 570);
            this.Abas.TabIndex = 0;
            this.Abas.Click += new System.EventHandler(this.Abas_Click);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Buscar.png");
            this.imageList1.Images.SetKeyName(1, "Deletar.png");
            this.imageList1.Images.SetKeyName(2, "Delete.png");
            this.imageList1.Images.SetKeyName(3, "Editar.png");
            this.imageList1.Images.SetKeyName(4, "Find.png");
            this.imageList1.Images.SetKeyName(5, "Info.png");
            this.imageList1.Images.SetKeyName(6, "Insert.png");
            this.imageList1.Images.SetKeyName(7, "R.png");
            this.imageList1.Images.SetKeyName(8, "Salvar.png");
            this.imageList1.Images.SetKeyName(9, "Update.png");
            this.imageList1.Images.SetKeyName(10, "Usuarios.png");
            // 
            // imgUsuarioLogado
            // 
            this.imgUsuarioLogado.Image = global::SupervisorioUsuarios.Properties.Resources.Conectado;
            this.imgUsuarioLogado.InitialImage = global::SupervisorioUsuarios.Properties.Resources.Conectado;
            this.imgUsuarioLogado.Location = new System.Drawing.Point(12, 11);
            this.imgUsuarioLogado.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.imgUsuarioLogado.Name = "imgUsuarioLogado";
            this.imgUsuarioLogado.Size = new System.Drawing.Size(40, 40);
            this.imgUsuarioLogado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgUsuarioLogado.TabIndex = 8;
            this.imgUsuarioLogado.TabStop = false;
            // 
            // imgUsuario
            // 
            this.imgUsuario.Image = ((System.Drawing.Image)(resources.GetObject("imgUsuario.Image")));
            this.imgUsuario.InitialImage = global::SupervisorioUsuarios.Properties.Resources.Desconectado;
            this.imgUsuario.Location = new System.Drawing.Point(12, 10);
            this.imgUsuario.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.imgUsuario.Name = "imgUsuario";
            this.imgUsuario.Size = new System.Drawing.Size(40, 40);
            this.imgUsuario.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.imgUsuario.TabIndex = 5;
            this.imgUsuario.TabStop = false;
            // 
            // tx_TamanhoBanco
            // 
            this.tx_TamanhoBanco.AutoSize = true;
            this.tx_TamanhoBanco.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tx_TamanhoBanco.Location = new System.Drawing.Point(1028, 447);
            this.tx_TamanhoBanco.Name = "tx_TamanhoBanco";
            this.tx_TamanhoBanco.Size = new System.Drawing.Size(169, 22);
            this.tx_TamanhoBanco.TabIndex = 421;
            this.tx_TamanhoBanco.Text = "Tamanho Banco:";
            this.tx_TamanhoBanco.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(64)))), ((int)(((byte)(71)))));
            this.ClientSize = new System.Drawing.Size(1474, 722);
            this.Controls.Add(this.imgUsuarioLogado);
            this.Controls.Add(this.lblInfoBanco);
            this.Controls.Add(this.lblInfoErro);
            this.Controls.Add(this.imgUsuario);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblHora);
            this.Controls.Add(this.lblMostraLogado);
            this.Controls.Add(this.Abas);
            this.Controls.Add(this.lblInfoLeitura);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form_Principal";
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Supervisório Usuários";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FecharForm);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage6_Info.ResumeLayout(false);
            this.tabPage6_Info.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage5_Excluir.ResumeLayout(false);
            this.tabPage4_Atualizar.ResumeLayout(false);
            this.tabPage3_Visualizar.ResumeLayout(false);
            this.tabPage3_Visualizar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Visualizar)).EndInit();
            this.tabPage2_Cadastrar.ResumeLayout(false);
            this.tabPage2_Cadastrar.PerformLayout();
            this.tabPage1_Login.ResumeLayout(false);
            this.tabPage1_Login.PerformLayout();
            this.Abas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.imgUsuarioLogado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imgUsuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblMostraLogado;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblHora;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblInfoLeitura;
        private System.Windows.Forms.PictureBox imgUsuario;
        private System.Windows.Forms.PictureBox imgUsuarioLogado;
        private System.Windows.Forms.Label lblInfoErro;
        private System.Windows.Forms.Label lblInfoBanco;
        private System.Windows.Forms.TabPage tabPage6_Info;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage5_Excluir;
        private System.Windows.Forms.TabPage tabPage4_Atualizar;
        private System.Windows.Forms.TabPage tabPage3_Visualizar;
        private System.Windows.Forms.TabPage tabPage2_Cadastrar;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TabPage tabPage1_Login;
        private System.Windows.Forms.Button btnDeslogar;
        private System.Windows.Forms.Button btnLogar;
        private System.Windows.Forms.TextBox tbxSenha;
        private System.Windows.Forms.TextBox tbxUsuario;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl Abas;
        private System.Windows.Forms.TextBox txbNomeCadastro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnCadastrar;
        private System.Windows.Forms.TextBox txbSenhaCadastro;
        private System.Windows.Forms.TextBox txbLoginCadastro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txbNivelCadastro;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Button BtnVisualizar;
        private System.Windows.Forms.Button BtnAtualizar;
        private System.Windows.Forms.Button BtnExcluir;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView_Visualizar;
        private System.Windows.Forms.TextBox txbNivelVisualizar;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txbNomeVisualizar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txbLoginVisualizar;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label tx_TamanhoBanco;
    }
}

