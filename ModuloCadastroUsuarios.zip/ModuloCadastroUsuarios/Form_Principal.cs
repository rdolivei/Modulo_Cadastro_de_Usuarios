﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Net;
using System.Data;
using System.Security.Cryptography;
using System.Text;


//using System.Runtime.CompilerServices;
//[assembly: SuppressIldasmAttribute()]


namespace Supervisorio
{

    public partial class Form_Principal : Form 
    {
        SqlConnection conexBD;
        SqlCommand cmdSQL;

        public String CordaConexaoSQL = @"Data Source=RICARDO\WINCC;" + "Initial Catalog=BancoUsuarios;" + "Integrated Security=SSPI;"; // essa para a minha maquina                    (Ricardo)
        public String CordaSQL_CriarBanco = @"Data Source=RICARDO\WINCC;" + "Initial Catalog=;" + "Integrated Security=SSPI;"; // essa string nao tem Initial Catalog=               (Ricardo)


#pragma warning disable 0168 // variable declared but not used. porque no Exception eu declarei nao to usando o "exem"

        TabPage tab2, tab3, tab4, tab5, tab10;
  
        public Form_Principal()
        {
            InitializeComponent();
            tbxUsuario.Focus();
            tbxUsuario.Select();
        }// fim evento Form_Principal

        // ********************************************************* eventos dos botoes das ABAS
        private void Abas_Click(object sender, EventArgs e)
        {
            if (Abas.SelectedIndex == 0) // aba 1 login
            {
                tbxUsuario.Focus();
            }
            if (Abas.SelectedIndex == 1) // aba 2 Leitura DB
            {
                BuscaTamanhoBanco();
            }
                        
            if (Abas.SelectedIndex == 2) // aba 3
            {
                dataGridView_Visualizar.DataSource = null; //Aqui limpa o GRID
                string escolheSql = "";
                txbNomeVisualizar.Text = "";
                txbLoginVisualizar.Text = "";
                txbNivelVisualizar.Text = "";

                try
                {
                    conexBD = new SqlConnection(CordaConexaoSQL);
                    conexBD.Open();
                    escolheSql = "USE BancoUsuarios SELECT id, nome, login ,nivel FROM [BancoUsuarios].[dbo].[Usuarios] WITH (NOLOCK)";
               
                    cmdSQL = new SqlCommand(escolheSql, conexBD);
                    cmdSQL.ExecuteNonQuery();

                    SqlDataAdapter da = new SqlDataAdapter(); /* da, adapta o banco de dados ao projeto */
                    DataSet ds = new DataSet();
                    da.SelectCommand = cmdSQL; // adapta cmd ao projeto
             
                    da.Fill(ds); // preenche todas as informações dentro do DataSet
              
                    this.Invoke(new MethodInvoker(delegate ()
                    {
                        dataGridView_Visualizar.DataSource = ds; //Datagridview recebe ds ja preenchido
                        dataGridView_Visualizar.DataMember = ds.Tables[0].TableName; //nome das colunas vindas do banco
                        // alterando o nome da coluna
                        dataGridView_Visualizar.Columns["id"].HeaderText = " ID ";
                        dataGridView_Visualizar.Columns["nome"].HeaderText = " NOME ";
                        dataGridView_Visualizar.Columns["login"].HeaderText = " USUÁRIO ";
                        dataGridView_Visualizar.Columns["nivel"].HeaderText = " NÍVEL ";
                    }));
                }
                catch (Exception ex)
                {
                    Console.WriteLine("errrroooo" + ex.ToString());
                }
                finally
                {
                    conexBD.Close();
                }

            }
            if (Abas.SelectedIndex == 3) // aba 4
            {

            }
            if (Abas.SelectedIndex == 4) // aba 5
            {
            }
            if (Abas.SelectedIndex == 5) // aba 6
            {

                BuscaTamanhoBanco();

            }
            if (Abas.SelectedIndex == 6) // aba 7
            {
            }
            if (Abas.SelectedIndex == 7) // aba 8
            {
            }
            if (Abas.SelectedIndex == 8) // aba 9
            {
            }
            if (Abas.SelectedIndex == 9) // aba 10
            {
            }

        }// fim evento Abas_Click

        private void Form1_Load(object sender, EventArgs e)
        {
            imgUsuarioLogado.Visible = false;

            tbxUsuario.Enabled = true;
            tbxSenha.Enabled = true;

            lblMostraLogado.Text = "";

            //atribuicao da variavel tab
            tab2 = tabPage2_Cadastrar;
            tab3 = tabPage3_Visualizar;
            tab4 = tabPage4_Atualizar;
            tab5 = tabPage5_Excluir;
            tab10 = tabPage6_Info;

            //remove as tabs para nao aparecer antes de logar
            Abas.TabPages.Remove(tab2);
            Abas.TabPages.Remove(tab3);
            Abas.TabPages.Remove(tab4);
            Abas.TabPages.Remove(tab5);

            btnDeslogar.Visible = false;

            tbxUsuario.Focus();

        }// fim metodo LOAD


        private void BtnCadastrar_Click(object sender, EventArgs e)
        {

            String nomeCadastro = txbNomeCadastro.Text;
            String loginCadastro = txbLoginCadastro.Text;
            String senhaCadastro = txbSenhaCadastro.Text;
            String nivelCadastro = txbNivelCadastro.Text;
            String SenhaHhashObtido = "";


            //Console.WriteLine(loginCadastro.Length.ToString());
            if(nomeCadastro.Length > 0 && loginCadastro.Length > 0 && senhaCadastro.Length > 0)
            {
                if (BuscaSeJaExiste(nomeCadastro, loginCadastro) == 0)
                {
                    using (SHA256 TipoSha256Hash = SHA256.Create())
                    {
                        SenhaHhashObtido = ObterUmHash(TipoSha256Hash, senhaCadastro);

                        if (VerificarUmHash(TipoSha256Hash, senhaCadastro, SenhaHhashObtido))
                        {
                            Console.WriteLine("O Hash e igual");
                        }
                        else
                        {
                            Console.WriteLine("O Hash nao eh igual");
                        }
                    }


                    try
                    {
                        conexBD.Open();
                        //SQL para insercao
                        cmdSQL = new SqlCommand("INSERT INTO [BancoUsuarios].[dbo].[Usuarios] (nome, login, senha, nivel) VALUES (" + "'" + nomeCadastro + "'" + "," + "'" + loginCadastro + "'" + "," + "'" + SenhaHhashObtido + "'" + "," + nivelCadastro + ")", conexBD);
                        cmdSQL.ExecuteNonQuery();


                        this.Invoke(new MethodInvoker(delegate ()
                        {
                            lblInfoBanco.Text = "Registro Inserido com Sucesso. \r\n";
                            lblInfoBanco.Refresh();

                            txbNomeCadastro.Text = "";
                            txbLoginCadastro.Text = "";
                            txbSenhaCadastro.Text = "";
                            txbNivelCadastro.Text = "";


                            txbNomeCadastro.Focus();
                            txbNomeCadastro.Select();

                        }));

                    }
                    catch (Exception ex)
                    {
                        this.Invoke(new MethodInvoker(delegate ()
                        {
                            lblInfoBanco.Text = "Erro ao Inserir Dados no Banco Usuarios. \r\n" + ex.Message;
                            lblInfoBanco.Refresh();
                        }));
                    }
                    finally
                    {
                        conexBD.Close();
                    }



                }
                else
                {
                    MessageBox.Show(this, " Usuário já existe ", " INFORMAÇÃO ", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                MessageBox.Show(this, " Campos Obrigatórios? ", " INFORMAÇÃO ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }


        }

        private void TabPage10_Sobre_Click(object sender, EventArgs e)
        {
            IPHostEntry host;
            string localIP;
            string ips = "";
            ips += " \r\n \r\n";
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily.ToString() == "InterNetwork")
                {
                    localIP = ip.ToString();
                    ips += localIP + " \r\n \r\n";
                }
            }
            MessageBox.Show(ips, " Meu(s) IP(s) ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void BtnLogar_Click(object sender, EventArgs e)
        {
            this.MeuEventoLogar();
        }// fim evento BtnLogar_Click

        public bool BuscaLogin(string login, string senha)
        {
            bool resultado = false;
            try
            {
                conexBD = new SqlConnection(CordaConexaoSQL);
                conexBD.Open();

                cmdSQL = new SqlCommand("USE BancoUsuarios SELECT nome, nivel FROM [BancoUsuarios].[dbo].[Usuarios] WITH (NOLOCK) where login = '" + login + "' and senha = '" + senha + "'", conexBD);
                cmdSQL.ExecuteNonQuery();

                using (SqlDataReader reader = cmdSQL.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        //while (reader.Read())
                        //{
                            reader.Read();
                            // o indice (x) eh a posicao na dos campos do banco de dados pelo select
                            lblMostraLogado.Text = "Usuário Logado: " + reader.GetString(0).ToString() + " Nível: " + (string)reader.GetInt32(1).ToString();
                            resultado = true;
                        //}
                            
                    }
                }

            }
            catch (Exception ex)
            {
                resultado = false;
                Console.WriteLine("Erro Buscar Login " + ex.ToString());
            }
            finally
            {
                conexBD.Close();
            }

            return resultado;
        }// fim evento BuscaLogin


        private void MeuEventoLogarEnter(object sender, KeyEventArgs e)
        {
            // aqui pega o evento do enter do teclado para logar
            if (e.KeyCode == Keys.Enter)
            {
               this.MeuEventoLogar();
            }
        }// fim evento MeuEventoLogarEnter

        public void MeuEventoLogar()
        {

            if (tbxUsuario.TextLength > 0 && tbxSenha.TextLength > 0)
            {
                string SenhaHhashObtido;
                using (SHA256 TipoSha256Hash = SHA256.Create())
                {
                    SenhaHhashObtido = ObterUmHash(TipoSha256Hash, tbxSenha.Text);
                }

                if (BuscaLogin(tbxUsuario.Text, SenhaHhashObtido))
                {
                    Abas.TabPages.Add(tab2);
                    Abas.TabPages.Add(tab3);
                    Abas.TabPages.Add(tab4);
                    Abas.TabPages.Add(tabPage5_Excluir);

                    imgUsuarioLogado.Visible = true;

                    Abas.TabPages.Remove(tab10);
                    Abas.TabPages.Add(tab10);

                    btnDeslogar.Visible = true;
                    btnLogar.Visible = false;
                    tbxUsuario.Enabled = false;
                    tbxSenha.Enabled = false;
                }
                else
                {
                    tbxUsuario.Focus();
                    tbxUsuario.Select();
                    MessageBox.Show("Login ou Senha Inválidos.", "Login Senha", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            else
            {
                tbxUsuario.Focus();
                tbxUsuario.Select();
                MessageBox.Show("Login ou Senha Campos Inválidos.", "Login Senha", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }// fim evento MeuEventoLogar

        private void BtnDeslogar_Click(object sender, EventArgs e)
        {

            imgUsuarioLogado.Visible = false;

            lblMostraLogado.Text = "";
            tbxUsuario.Text = "";
            tbxSenha.Text = "";

            Abas.TabPages.Remove(tab2);
            Abas.TabPages.Remove(tab3);
            Abas.TabPages.Remove(tab4);
            Abas.TabPages.Remove(tab5);
            Abas.TabPages.Remove(tab10);
            Abas.TabPages.Add(tab10);

            btnDeslogar.Visible = false;
            btnLogar.Visible = true;

            tbxUsuario.Enabled = true;
            tbxSenha.Enabled = true;

            tbxUsuario.Focus();
            tbxUsuario.Select();

        }// fim evento BtnDeslogar_Click

        public void BuscaTamanhoBanco()
        {
            // leitura tamanho do banco
            try
            {
                conexBD = new SqlConnection(CordaConexaoSQL);
                conexBD.Open();
                // acri cria provisoriamente um campo (Tamanho_em_MB) para mostrar o tamanho do banco .............. O  WITH (NOLOCK) NAO BLOQUEIA PARA ESSA CONSULTA
                cmdSQL = new SqlCommand("USE BancoUsuarios SELECT (SUM(SIZE) / 128) AS Tamanho_em_MB FROM SYS.database_files WITH (NOLOCK)", conexBD);
                cmdSQL.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter(); /* da, adapta o banco de dados ao projeto */
                DataSet ds = new DataSet();
                da.SelectCommand = cmdSQL; // adapta cmd ao projeto
                da.Fill(ds); // preenche todas as informações dentro do DataSet

                this.Invoke(new MethodInvoker(delegate ()
                {
                    //Console.WriteLine("Busca do Tamanho do Banco = " + ds.Tables[0].Rows[0]["Tamanho_em_MB"].ToString());
                    tx_TamanhoBanco.Text = "Tamanho do Banco: " + ds.Tables[0].Rows[0]["Tamanho_em_MB"].ToString() + "MB";
                    tx_TamanhoBanco.Refresh();
                }));
            }
            catch (Exception ex)
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    tx_TamanhoBanco.Text = "Erro";
                    tx_TamanhoBanco.Refresh();
                }));
            }
            finally
            {
                conexBD.Close();
            }

            //Console.WriteLine("Busca do Tamanho do Banco");

        }// fim evento BuscaTamanhoBanco

        private void Timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                this.Invoke(new MethodInvoker(delegate ()
                {
                    //aqui carrega a data e hora para mostar na tela
                    lblData.Text = DateTime.Now.ToShortDateString();
                    lblData.Refresh();
                    lblHora.Text = (DateTime.Now.ToString("HH:mm:ss"));
                    lblHora.Refresh();
                }));
            }
            catch (Exception ex)
            {
            }

        }// fim evento Timer1_Tick

        private void BtnVisualizar_Click(object sender, EventArgs e)
        {
            //Abas.SelectedTab = tabPage6_Info;

            dataGridView_Visualizar.DataSource = null; //Aqui limpa o GRID
            string escolheSql = "";

            string nomeV = txbNomeVisualizar.Text.ToString();
            string loginV = txbLoginVisualizar.Text.ToString();
            string nivelV = txbNivelVisualizar.Text.ToString();

            Console.WriteLine("Nivel=["+nivelV.ToString()+"]");

            if(nomeV.Length > 0) nomeV += "%";
            if (loginV.Length > 0) loginV += "%";
            if (nivelV.Length <= 0) nivelV = "0";

            try
            {

                conexBD = new SqlConnection(CordaConexaoSQL);
                conexBD.Open();
                escolheSql = "USE BancoUsuarios SELECT id, nome, login ,nivel FROM [BancoUsuarios].[dbo].[Usuarios] WITH (NOLOCK) where nome LIKE '" + nomeV + "' or login LIKE '" + loginV + "' or nivel = " + nivelV;

                Console.WriteLine(escolheSql);

                cmdSQL = new SqlCommand(escolheSql, conexBD);
                cmdSQL.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter(); /* da, adapta o banco de dados ao projeto */
                DataSet ds = new DataSet();
                da.SelectCommand = cmdSQL; // adapta cmd ao projeto

                da.Fill(ds); // preenche todas as informações dentro do DataSet

                this.Invoke(new MethodInvoker(delegate ()
                {
                    dataGridView_Visualizar.DataSource = ds; //Datagridview recebe ds ja preenchido
                    dataGridView_Visualizar.DataMember = ds.Tables[0].TableName; //nome das colunas vindas do banco

                    // alterando o nome da coluna
                    dataGridView_Visualizar.Columns["id"].HeaderText = " ID ";
                    dataGridView_Visualizar.Columns["nome"].HeaderText = " NOME ";
                    dataGridView_Visualizar.Columns["login"].HeaderText = " USUÁRIO ";
                    dataGridView_Visualizar.Columns["nivel"].HeaderText = " NÍVEL ";


                }));


            }
            catch (Exception ex)
            {
                Console.WriteLine("errrroooo" + ex.ToString());
            }
            finally
            {
                conexBD.Close();
            }

        }

        private void FecharForm(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                var result = MessageBox.Show(this, " Você tem Certeza que Deseja Sair? ", " CONFIRMAÇÃO ", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (result != DialogResult.Yes)
                {
                    e.Cancel = true; //nao fecha a aplicacao
                }
                else
                {
                    e.Cancel = false; // fecha a aplicacao
                }
            }
        }// fim evento FecharForm


        public int BuscaSeJaExiste(string nome, string login)
        {
            int resultado = 99;
            try
            {
                conexBD = new SqlConnection(CordaConexaoSQL);
                conexBD.Open();
                // acri cria provisoriamente um campo (contagem) para contar se ja tem usuario .............. O  WITH (NOLOCK) NAO BLOQUEIA PARA ESSA CONSULTA
                cmdSQL = new SqlCommand("USE BancoUsuarios SELECT COUNT(nome) AS contagem FROM [BancoUsuarios].[dbo].[Usuarios] WITH (NOLOCK) where nome = '" + nome + "' and login = '" + login + "'", conexBD);
                cmdSQL.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter(); /* da, adapta o banco de dados ao projeto */
                DataSet ds = new DataSet();
                da.SelectCommand = cmdSQL; // adapta cmd ao projeto
                da.Fill(ds); // preenche todas as informações dentro do DataSet

                resultado = (int)ds.Tables[0].Rows[0]["contagem"];
            }
            catch (Exception ex)
            {
                Console.WriteLine("Errrrrooooooo " + ex.ToString());
            }
            finally
            {
                conexBD.Close();
            }

            return resultado;
        }// fim evento BuscaSeJaExiste


        // ------------------------------------------ METODOS PARA CRIPTOGRAFAR ------------------------------------------
        private static string ObterUmHash(HashAlgorithm hashAlgoritmoTipo, string textoSenhaInformada)
        {
            // Converte a senha informada para um array de byte
            byte[] data = hashAlgoritmoTipo.ComputeHash(Encoding.UTF8.GetBytes(textoSenhaInformada));
            // Cria um novo Stringbuilder
            var construtorString = new StringBuilder();
            // Percorre o laco por hexadecimal
            for (int i = 0; i < data.Length; i++)
            {
                construtorString.Append(data[i].ToString("x2"));
            }
            // Retorna o hash
            return construtorString.ToString();
        }

        // Verify a hash against a string.
        private static bool VerificarUmHash(HashAlgorithm algoritmoHashTipo, string senhaInformada, string hashGerada)
        {
            // Carrega o hash
            var hashCriado = ObterUmHash(algoritmoHashTipo, senhaInformada);
            // Cria o comparador
            StringComparer comparador = StringComparer.OrdinalIgnoreCase;
            // reorna o resultado da comparacao
            return comparador.Compare(hashCriado, hashGerada) == 0;
        }
    

    }// fim Form_Principal
}// fim namespace Supervisorio
